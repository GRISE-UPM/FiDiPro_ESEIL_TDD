/*
 * Frame.cpp
 *
 *  Created on: Jan 19, 2014
 *      Author: fidipro
 */

#include "Frame.h"

Frame::Frame() {
	// TODO Auto-generated constructor stub

}

Frame::Frame(int b1, bool lF) {
	// TODO Auto-generated constructor stub
	ball1 = b1;
	ball2 = 0;
	ball3 = 0;
	lastFrame = lF;
}

Frame::Frame(int b1, int b2, bool lF) {
	// TODO Auto-generated constructor stub
	ball1 = b1;
	ball2 = b2;
	ball3 = 0;
	lastFrame = lF;
}

Frame::Frame(int b1, int b2, int b3, bool lF) {
	// TODO Auto-generated constructor stub
	ball1 = b1;
	ball2 = b2;
	ball3 = b3;
	lastFrame = lF;
}

Frame::~Frame() {
	// TODO Auto-generated destructor stub
}

//the score of a single frame
int Frame::score(){
	//to be implemented
	if (lastFrame == true)
	{
		if (ball1 == 10){
			if (ball2 == 10)
			{
				return (ball1 + ball2 + ball3 + ball2 + ball3 + ball3);
			}
			else{
				return (ball1 + ball2 + ball3 + ball2 + ball3);
			}
		}
		else{
			if (ball1 + ball2 == 10){
				return (ball1 + ball2 + ball3 + ball3);
			}
			else{
				return (ball1 + ball2);
			}
		}
	}
	else
		return (ball1 + ball2);
}

//returns whether the frame is a strike or not
bool Frame::isStrike(){
	//to be implemented
	if (ball1 == 10)
		return true;
	else
		return false;
}

//return whether a frame is a spare or not
bool Frame::isSpare(){
	//to be implemented
	if (!(ball1 == 10))
	{
		if (ball1 + ball2 == 10)
			return true;
		else
			return false;
	}
	else {
		return false;
	}

}

//return whether this is the last frame of the match
bool Frame::isLastFrame(){
	//to be implemented
	return lastFrame;
}

//bonus throws
int Frame::bonus(){
	//to be implemented
	return 0;
}
