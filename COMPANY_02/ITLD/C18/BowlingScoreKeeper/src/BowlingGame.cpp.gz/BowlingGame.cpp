/*
 * BowlingGame.cpp
 *
 *  Created on: Jan 19, 2014
 *      Author: fidipro
 */

#include "BowlingGame.h"
#include <string>

BowlingGame::BowlingGame() {
	amountOfFrames = 0;
}

BowlingGame::~BowlingGame() {
	// TODO Auto-generated destructor stub
}

void BowlingGame::addFrame(Frame frame){
	//to be implemented'
	frames.insert(frames.end(), frame);
	amountOfFrames++;
}

void BowlingGame::setBonus(int firstThrow, int secondThrow) {
	//to be implemented
}

int BowlingGame::score(){
	//to be implemented
	int result = 0;

	for (int i=0; i<amountOfFrames; i++){
		if (frames[i].isSpare() && !(frames[i].isLastFrame())) {
			result += frames[i].score() + frames[i+1].ball1;
		}
		else {
			result += frames[i].score();
		}/*
		if (frames[i].isStrike() && !(frames[i].isLastFrame())) {
			result += frames[i].score() + frames[i+1].score();
		}
		else {
			result += frames[i].score();
		}*/
	}
	/*
	for (int i=0; i<amountOfFrames; i++){
		if (frames[i].lastFrame){
			result += frames[i].score();
		}
		else{
			if ( frames[i].isStrike()){
				if ( frames[i+1].isLastFrame())
					result += frames[i].score() + frames[i+1].score();
				else
					if ( !(frames[i+1].isSpare() && frames[i+1].isStrike())){
						result += frames[i].score() + frames[i+1].score();
					}

			}
			if ( frames[i].isSpare()){
				if (frames[i+1].isStrike()){
					// todo
				}
				else{
					result += frames[i].score() + frames[i+1].ball1;
				}

			}
			result += frames[i].score();

		}
	}*/
/*
	if (amountOfFrames > 0){
		for (int i=amountOfFrames; i>=0; i--){
			result += frames[i].score();
		}
	}
*/
	return result;
}

bool BowlingGame::isNextFrameBonus(){
	//to be implemented
	return false;
}
