#define BOOST_TEST_MODULE BSK_tests
#include <boost/test/unit_test.hpp>

#include "../src/BowlingGame.h"
#include "../src/Frame.h"

BOOST_AUTO_TEST_CASE (smoke_test)
{
  BowlingGame game;
  BOOST_CHECK_EQUAL(0, game.score());
}

BOOST_AUTO_TEST_CASE (add_frame)
{
  BowlingGame game;
  Frame testFrame1(1,5, false);
  Frame testFrame2(3,4, false);
  game.addFrame(testFrame1);
  game.addFrame(testFrame2);
  BOOST_CHECK_EQUAL(6, testFrame1.score());
  BOOST_CHECK_EQUAL(7, testFrame2.score());
  BOOST_CHECK_EQUAL(13, game.score());
}

BOOST_AUTO_TEST_CASE (add_10_frames)
{
  BowlingGame game;
  Frame testFrame1(1,1, false);
  Frame testFrame2(1,1, false);
  Frame testFrame3(1,1, false);
  Frame testFrame4(1,1, false);
  Frame testFrame5(1,1, false);
  Frame testFrame6(1,1, false);
  Frame testFrame7(1,1, false);
  Frame testFrame8(1,1, false);
  Frame testFrame9(1,1, false);
  Frame testFrame10(1,1, false);

  game.addFrame(testFrame1);
  game.addFrame(testFrame2);
  game.addFrame(testFrame3);
  game.addFrame(testFrame4);
  game.addFrame(testFrame5);
  game.addFrame(testFrame6);
  game.addFrame(testFrame7);
  game.addFrame(testFrame8);
  game.addFrame(testFrame9);
  game.addFrame(testFrame10);
  BOOST_CHECK_EQUAL(20, game.score());
}

BOOST_AUTO_TEST_CASE (test_Frame_Spare_and_Strike)
{
  Frame testFrame1(5,5, false);
  Frame testFrame2(10, false);
  BOOST_CHECK_EQUAL(true, testFrame1.isSpare());
  BOOST_CHECK_EQUAL(false, testFrame1.isStrike());
  BOOST_CHECK_EQUAL(false, testFrame2.isSpare());
  BOOST_CHECK_EQUAL(true, testFrame2.isStrike());
}

BOOST_AUTO_TEST_CASE (test_game_Spare)
{
  BowlingGame game;
  Frame testFrame1(5,5, false);
  Frame testFrame2(1,0, false);
  game.addFrame(testFrame1);
  game.addFrame(testFrame2);
  BOOST_CHECK_EQUAL(10, testFrame1.score());
  BOOST_CHECK_EQUAL(1, testFrame2.score());
  BOOST_CHECK_EQUAL(12, game.score());
}

BOOST_AUTO_TEST_CASE (test_game_Strike)
{
  BowlingGame game;
  Frame testFrame1(10, false);
  Frame testFrame2(1,1, false);
  game.addFrame(testFrame1);
  game.addFrame(testFrame2);
  BOOST_CHECK_EQUAL(10, testFrame1.score());
  BOOST_CHECK_EQUAL(2, testFrame2.score());
  BOOST_CHECK_EQUAL(14, game.score());
}
